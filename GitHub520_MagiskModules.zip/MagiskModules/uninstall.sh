rm -rf /data/adb/github520
rm -rf /data/adb/modules/GitHub520